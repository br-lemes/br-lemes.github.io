solution "hello"
  configurations { "Debug", "Release" }
  configuration "Debug"
    defines { "DEBUG" }
    flags { "Symbols" }
  configuration "Release"
    flags { "Optimize" }

  project "hello"
    kind "ConsoleApp"
    language "C"
    files { "hello.c", "file.c" }
