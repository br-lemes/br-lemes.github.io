solution "hello"
  configurations { "Debug", "Release" }
  configuration "Debug"
    defines { "DEBUG" }
    flags { "Symbols" }
  configuration "Release"
    flags { "Optimize" }

  project "hello"
    kind "ConsoleApp"
    language "C"
    files { "hello.c" }
    links { "libhello" }

  project "libhello"
    kind "SharedLib"
    language "C"
    files { "libhello.c" }

if _ACTION == "clean" then
  os.rmdir("obj")
  for i,v in ipairs(os.matchfiles("*.a")) do
    os.remove(v)
  end
end
