solution "hello"
  configurations { "Debug", "Release" }
  configuration "Debug"
    defines { "DEBUG" }
    flags { "Symbols" }
  configuration "Release"
    flags { "Optimize" }

  project "hello"
    kind "ConsoleApp"
    language "C"
    files { "hello.c" }
    links { "libhello" }

  project "libhello"
    kind "StaticLib"
    language "C"
    files { "libhello.c" }

if _ACTION == "clean" then
  os.rmdir("obj")
end
