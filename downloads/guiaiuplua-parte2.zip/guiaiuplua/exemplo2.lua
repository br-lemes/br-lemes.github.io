require( "iuplua" )

b = iup.Alarm("Exemplo IupAlarm", "Arquivo n�o salvo! Salv�-lo agora?" ,"Sim" ,"N�o" ,"Cancelar")

-- Mostra uma mensagem para cada bot�o selecionado
if b == 1 then
  iup.Message("Salvar arquivo", "Arquivo salvo com sucesso - saindo do programa")
elseif b == 2 then
  iup.Message("Salvar arquivo", "Arquivo n�o salvo - saindo mesmo assim")
elseif b == 3 then
  iup.Message("Salvar arquivo", "Opera��o cancelada")
end
