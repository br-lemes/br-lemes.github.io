require 'iuplua'

res = iup.GetText("Me d� seu nome","")

if res ~= "" then
    iup.Message("Obrigado!",res)
end
