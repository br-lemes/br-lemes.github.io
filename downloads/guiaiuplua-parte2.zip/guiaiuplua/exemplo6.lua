require( "iuplua" )
require( "iupluacontrols" )

res, prof = iup.GetParam("T�tulo", nil,
    "D� sua profiss�o: %l|Professor|Explorador|Engenheiro|\n",0)
    