require( "iuplua" )

iup.Message('Seu Aplicativo','Conclu�do com sucesso!')
