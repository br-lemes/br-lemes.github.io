require( "iuplua" )
require( "iupluacontrols" )

res, age = iup.GetParam("T�tulo", nil,
    "D� a sua idade: %i\n",0)

if res ~= 0 then    -- o usu�rio colaborou!
    iup.Message("S�rio?",age)
end