require( "iuplua" )

f, err = iup.GetFile("*.txt")
if err == 1 then
  iup.Message("Novo arquivo", f)
elseif err == 0 then
  iup.Message("Arquivo j� existente", f)
elseif err == -1 then
  iup.Message("IupFileDlg", "Opera��o cancelada")
end
