require( "iuplua" )
require( "iupluacontrols" )

res, name = iup.GetParam("T�tulo", nil,
    "D� o seu nome: %s\n","")

iup.Message("Ol�!",name)
